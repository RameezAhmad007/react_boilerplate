import React from "react";
import "./styles.scss";
function ChildContainer(props) {
  const { children, expandMenu } = props;
  return (
    <div
      className={`container_child_container ${
        expandMenu ? "container_child_container_expand" : ""
      }`}
    >
      {children}
      ChildContainer
    </div>
  );
}

export default ChildContainer;
