import React from 'react'
import './styles.scss'
const SideMenu=(props)=> {
    
  const { expandMenu } = props;
  return (
    <aside className={`side_menu_container ${expandMenu ? "side_menu_container_expand":""}`}>SideMenu</aside>
  )
}

export default SideMenu