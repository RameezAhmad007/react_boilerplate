import "./App.css";
import Container from "./components/container";

function App() {
  return (
    <Container>
      <h1>hello world</h1>
      <h1>hello world1</h1>
      <h1>hello world2</h1>
      <h1>hello world3</h1>
    </Container>
  );
}

export default App;
